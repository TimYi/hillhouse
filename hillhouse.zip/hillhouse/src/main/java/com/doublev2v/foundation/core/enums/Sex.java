package com.doublev2v.foundation.core.enums;

/**
 * 性别 0-女性，1-男性
 * @author pc
 *
 */
public enum Sex {
	男,女,
}
