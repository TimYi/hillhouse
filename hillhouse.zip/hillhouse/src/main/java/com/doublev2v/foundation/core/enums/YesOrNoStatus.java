package com.doublev2v.foundation.core.enums;

/**
 * 有时经常不希望删除数据，只是将数据标记为删除，便于数据分析。
 * @author pc
 *
 */
public enum YesOrNoStatus {
	YES,NO,
}
