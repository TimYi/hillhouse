package com.doublev2v.foundation.core.model;

public interface GenericClassCreator<T> {
	T create();
}
