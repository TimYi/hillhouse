package com.doublev2v.foundation.media;

import org.springframework.stereotype.Repository;

import com.doublev2v.foundation.core.repository.BaseModelRepository;

@Repository
public class MediaContentRepository extends BaseModelRepository<MediaContent, String> {
}
