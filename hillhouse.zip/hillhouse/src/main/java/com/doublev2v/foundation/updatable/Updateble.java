package com.doublev2v.foundation.updatable;

public interface Updateble<D> {
	D update(D d);
}
