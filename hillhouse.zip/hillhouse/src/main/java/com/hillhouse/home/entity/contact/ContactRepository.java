package com.hillhouse.home.entity.contact;

import org.springframework.stereotype.Repository;

import com.doublev2v.foundation.core.repository.BaseModelRepository;

@Repository
public class ContactRepository extends BaseModelRepository<Contact, String> {
	
}
