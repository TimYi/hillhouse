package com.hillhouse.home.entity.figure;

import org.springframework.stereotype.Repository;

import com.hillhouse.home.base.LanguagePriorityModelRepository;

@Repository
public class FigureRepository extends LanguagePriorityModelRepository<Figure> {
}
