package com.hillhouse.home.entity.news;

import org.springframework.stereotype.Component;

import com.doublev2v.foundation.core.model.AbstractGenericClassCreator;

@Component
public class NewsCreator extends AbstractGenericClassCreator<News> {

}
