package com.hillhouse.home.entity.news.dto;

import org.springframework.stereotype.Component;

import com.hillhouse.home.entity.news.News;

@Component
public class NewsDTOAdapter extends AbstractNewsDTOAdapter<News> {
}
