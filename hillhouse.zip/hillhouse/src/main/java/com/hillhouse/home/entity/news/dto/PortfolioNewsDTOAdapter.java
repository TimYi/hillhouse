package com.hillhouse.home.entity.news.dto;

import org.springframework.stereotype.Component;

import com.hillhouse.home.entity.news.PortfolioNews;

@Component
public class PortfolioNewsDTOAdapter extends AbstractNewsDTOAdapter<PortfolioNews> {
}
