package com.hillhouse.home.entity.story;

import org.springframework.stereotype.Repository;

import com.hillhouse.home.base.LanguageModelRepository;

@Repository
public class StoryRepository extends LanguageModelRepository<Story> {

}
